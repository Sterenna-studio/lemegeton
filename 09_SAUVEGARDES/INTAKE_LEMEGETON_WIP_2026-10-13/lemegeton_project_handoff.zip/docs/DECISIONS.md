# Décisions de projet

## Confirmées

-   Projet centré sur Lemegeton, robot rétro inspiré du Minitel.
-   Windows comme environnement cible initial.
-   Godot est le moteur recommandé pour partager le runtime entre jeu 2D
    et compagnon de bureau.
-   L'utilisateur débute en animation 2D.
-   Style d'animation : marionnette de papier articulée / cut-out.
-   Utiliser exclusivement les assets graphiques existants ; aucune
    nouvelle illustration.
-   Les variantes de mains et d'expressions doivent être traitées comme
    des états alternatifs.
-   Une pose du personnage ne doit jamais montrer des mains dupliquées
    par erreur.

## Recommandations, non encore validées

-   Godot 4.x comme base de développement.
-   Construire d'abord le personnage jouable, puis ajouter le mode
    compagnon de bureau.
-   Commencer par une hiérarchie de pivots `Node2D` + `Sprite2D`, puis
    envisager `Skeleton2D` si les besoins le justifient.
-   Garder Synfig Studio facultatif ; ne pas ajouter un deuxième outil
    tant que le pipeline Godot n'est pas validé.
-   Le mode compagnon doit être une scène/mode distinct, partageant les
    assets et animations du personnage.

## À décider plus tard

-   Version exacte de Godot.
-   Vue et gameplay précis (plateformer, aventure, autre).
-   Système de caméra et dimensions du monde.
-   Interactions spécifiques du compagnon.
-   Gestion des clics traversants dans la fenêtre transparente.
-   Licence et provenance de chaque asset si le projet est publié.
