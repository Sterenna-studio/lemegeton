# Inventaire du pack source

Pack de référence : `source_assets/lemegeton_kit_rig_2d_original.zip`

Le ZIP source contient un `manifest_assets.json` avec les dimensions et
chemins des assets. Répartition issue du manifeste :

-   **antenne** : 4 asset(s)
-   **bras** : 5 asset(s)
-   **commandes** : 3 asset(s)
-   **details** : 6 asset(s)
-   **expressions** : 10 asset(s)
-   **jambes** : 5 asset(s)
-   **mains** : 8 asset(s)
-   **pieds** : 6 asset(s)
-   **tete** : 6 asset(s)
-   **torse** : 4 asset(s)

## Liste des assets déclarés

  Chemin                                 Catégorie         Dimensions
  -------------------------------------- ------------- --------------
  `expressions/ecran_neutre.png`         expressions     124 × 118 px
  `expressions/ecran_heureux.png`        expressions     124 × 118 px
  `expressions/ecran_content.png`        expressions     124 × 118 px
  `expressions/ecran_clin_oeil.png`      expressions     124 × 118 px
  `expressions/ecran_joyeux.png`         expressions     126 × 118 px
  `expressions/ecran_surpris.png`        expressions     124 × 122 px
  `expressions/ecran_inquiet.png`        expressions     124 × 122 px
  `expressions/ecran_triste.png`         expressions     124 × 122 px
  `expressions/ecran_determine.png`      expressions     124 × 122 px
  `expressions/ecran_enerve.png`         expressions     126 × 122 px
  `tete/tete_face.png`                   tete            267 × 258 px
  `tete/tete_profil_gauche.png`          tete            174 × 247 px
  `tete/tete_profil_droit.png`           tete            177 × 248 px
  `tete/tete_trois_quarts_gauche.png`    tete            185 × 206 px
  `tete/tete_dos.png`                    tete            217 × 206 px
  `tete/tete_trois_quarts_droit.png`     tete            216 × 206 px
  `antenne/antenne_standard.png`         antenne          85 × 139 px
  `antenne/antenne_signal_grande.png`    antenne         134 × 190 px
  `antenne/antenne_signal_moyenne.png`   antenne          82 × 132 px
  `antenne/antenne_signal_petite.png`    antenne          60 × 100 px
  `details/grille_arriere.png`           details         141 × 125 px
  `details/plaque_nom.png`               details          156 × 87 px
  `details/connectique_arriere.png`      details          155 × 62 px
  `details/panneau_bas.png`              details          127 × 57 px
  `details/vis_rondes.png`               details           78 × 59 px
  `details/petite_plaque.png`            details           97 × 57 px
  `torse/torse_face_clavier.png`         torse           279 × 212 px
  `torse/torse_profil_gauche.png`        torse           153 × 213 px
  `torse/torse_profil_droit.png`         torse           154 × 213 px
  `torse/torse_dos.png`                  torse           259 × 213 px
  `bras/epaule_rotule.png`               bras             89 × 119 px
  `bras/bras_superieur.png`              bras            114 × 105 px
  `bras/bras_inferieur.png`              bras             113 × 96 px
  `bras/poignet.png`                     bras            114 × 115 px
  `bras/bras_extensible_spirale.png`     bras            474 × 100 px
  `mains/main_ouverte.png`               mains             99 × 97 px
  `mains/main_pointee.png`               mains             96 × 97 px
  `mains/main_pouce_haut.png`            mains             96 × 97 px
  `mains/main_pointe.png`                mains            121 × 97 px
  `mains/main_poing.png`                 mains             86 × 94 px
  `mains/main_ok.png`                    mains             96 × 94 px
  `mains/main_grab.png`                  mains            105 × 94 px
  `mains/main_plate.png`                 mains            118 × 94 px
  `jambes/hanche_rotule.png`             jambes           84 × 107 px
  `jambes/cuisse.png`                    jambes           89 × 136 px
  `jambes/genou.png`                     jambes           84 × 112 px
  `jambes/jambe_inferieure.png`          jambes           98 × 136 px
  `jambes/pied_detache.png`              jambes          143 × 121 px
  `pieds/pied_face.png`                  pieds           108 × 112 px
  `pieds/pied_profil.png`                pieds           107 × 106 px
  `pieds/pied_trois_quarts.png`          pieds           111 × 115 px
  `pieds/pied_arriere.png`               pieds           108 × 112 px
  `pieds/pied_vue_haute.png`             pieds            93 × 119 px
  `pieds/semelle.png`                    pieds           106 × 147 px
  `commandes/clavier_detail.png`         commandes       235 × 130 px
  `commandes/boutons_lateraux.png`       commandes        81 × 130 px
  `commandes/touches_fonction.png`       commandes       174 × 110 px

## Règles d'utilisation

-   Le ZIP original est la source canonique ; ne pas modifier son
    contenu.
-   Copier les assets sélectionnés vers le projet Godot sans renommer
    l'original dans l'archive.
-   Conserver les PNG d'expressions comme états exclusifs.
-   Conserver les PNG de mains comme variantes ; une seule variante par
    main visible à la fois.
-   Vérifier visuellement les découpes et transparences avant
    intégration finale.
-   Les fichiers de détails (grilles, vis, plaques, connectique,
    clavier) sont optionnels pour la première version jouable.

## Limites de l'inventaire

La présence d'un fichier dans le manifeste ne garantit pas qu'il soit
immédiatement exploitable pour un rig : certains éléments sont des vues
complètes, d'autres des variantes d'orientation, et certaines découpes
peuvent garder des artefacts. L'inventaire doit être complété par une
validation visuelle dans le prototype.
