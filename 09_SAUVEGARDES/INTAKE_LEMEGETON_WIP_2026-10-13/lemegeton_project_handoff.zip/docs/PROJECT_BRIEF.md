# Brief de projet --- Lemegeton

## Vision

Faire de Lemegeton un personnage expressif et contrôlable qui peut vivre
dans un jeu 2D et sous forme de compagnon de bureau Windows.

## Expérience recherchée

-   Le joueur contrôle le déplacement du personnage dans un
    environnement 2D.
-   Le personnage dispose d'animations lisibles et d'expressions
    d'écran.
-   Le même personnage peut être lancé dans un mode compagnon de bureau,
    plus léger et réactif aux interactions.
-   Les deux modes partagent le même système d'assets et d'animations.

## Direction artistique

Robot chibi rétro inspiré d'un Minitel, écran CRT, expressions
pixelisées cyan/magenta, coque noire marbrée aux veines dorées/cuivrées,
torse-clavier, antenne, membres courts. Rendu cut-out/paper-puppet à
partir des PNG fournis : superposition, pivots et animation des parties.

## Contraintes

-   Windows en priorité.
-   Gratuit et open source de préférence.
-   L'utilisateur est débutant en animation 2D.
-   Aucun nouvel artwork généré pour la suite immédiate.
-   Les prototypes existants sont de la documentation visuelle, pas des
    assets source autoritaires.

## Hors périmètre de la première version

-   Refondre le design du personnage.
-   Générer de nouveaux sprites.
-   Produire immédiatement un système complexe de dialogue ou d'IA.
-   Faire du compagnon de bureau une application autonome avant
    validation du personnage de base.
