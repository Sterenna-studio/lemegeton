# Feuille de route

## M0 --- Audit du pack

-   [ ] Décompresser le pack source original dans une zone en lecture
    seule.
-   [ ] Vérifier le manifeste et l'aperçu de toutes les catégories.
-   [ ] Marquer les assets validés, les assets avec artefacts et les
    vues complètes non séparables.
-   [ ] Choisir une seule pose neutre de main par côté.
-   [ ] Confirmer la convention de nommage et la licence/provenance.

**Critère de sortie :** inventaire fiable, aucun asset source écrasé.

## M1 --- Prototype Godot jouable

-   [ ] Créer projet Godot 2D Windows.
-   [ ] Importer les PNG sélectionnés.
-   [ ] Construire la hiérarchie visuelle avec pivots `Node2D`.
-   [ ] Ajouter déplacement gauche/droite et saut.
-   [ ] Ajouter collisions sol.
-   [ ] Créer états idle, marche, saut (même si la première animation
    est minimale).
-   [ ] Ajouter une commande de changement d'expression.
-   [ ] Tester et documenter les contrôles.

**Critère de sortie :** un build local où Lemegeton peut se déplacer et
sauter sans artefacts majeurs.

## M2 --- Cut-out rig

-   [ ] Corriger les pivots
    cou/épaules/coudes/poignets/hanches/genoux/chevilles.
-   [ ] Vérifier les chevauchements en rotation.
-   [ ] Corriger l'ordre de profondeur.
-   [ ] Ajouter variantes de main comme états remplaçables.
-   [ ] Ajouter les expressions comme états exclusifs.
-   [ ] Tester une animation de salut et une marche simple.

**Critère de sortie :** mouvements lisibles, sans duplication des
membres et sans séparations visuelles grossières.

## M3 --- Compagnon de bureau

-   [ ] Ajouter un mode d'exécution distinct.
-   [ ] Tester fenêtre sans bordure, transparence et always-on-top sous
    Windows.
-   [ ] Déplacer le personnage à la souris.
-   [ ] Ajouter clics/réactions.
-   [ ] Prévoir une manière de quitter et de revenir au mode jeu.
-   [ ] Vérifier si la fenêtre doit recevoir les clics ou les laisser
    traverser lorsqu'elle est inactive.

**Critère de sortie :** compagnon de bureau utilisable sans empêcher
l'utilisation normale de Windows.

## M4 --- Distribution

-   [ ] Configurer export Windows.
-   [ ] Tester sur une session Windows propre.
-   [ ] Rédiger instructions de lancement.
-   [ ] Séparer assets sources, fichiers importés et assets optimisés.
-   [ ] Ajouter captures d'écran uniquement après validation du
    prototype.
