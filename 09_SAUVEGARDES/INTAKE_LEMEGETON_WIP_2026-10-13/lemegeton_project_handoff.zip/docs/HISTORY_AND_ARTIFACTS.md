# Historique des travaux et livrables antérieurs

Les fichiers ci-dessous sont conservés comme références de travail.
Aucun n'est à considérer comme rig de production validé.

## Source canonique

-   `source_assets/lemegeton_kit_rig_2d_original.zip` : pack transmis
    par l'utilisateur, à traiter comme source de référence et à
    conserver intact.

## Références de travail incluses dans l'archive

-   `reference_artifacts/lemegeton_synfig_starter.zip` : préparation
    pour Synfig, avec PNG placés sur une toile commune, aperçu, document
    OpenRaster et pivots estimés. Gabarit, pas un rig Synfig natif
    final.
-   `reference_artifacts/lemegeton_cutout_rig_v2.zip` : assemblage SVG
    et manifeste de pivots. Prototype d'assemblage, pas un rig final.
-   `reference_artifacts/lemegeton_animation_test.zip` : GIF de salut
    rudimentaire et images de frames. Test visuel seulement.
-   `reference_artifacts/lemegeton_rig_2d_editable.zip` : premier SVG
    d'assemblage éditable, à conserver pour historique.
-   `reference_artifacts/lemegeton_modele_maitre_2d.zip` : première
    composition de référence et overlay de pivots.

## Leçons déjà identifiées

-   Une composition d'assets n'est pas équivalente à un rig animé.
-   Les mains en double étaient un défaut repéré : une seule main par
    bras dans la pose maître.
-   Les pivots des anciens prototypes sont approximatifs.
-   Certaines pièces peuvent contenir des résidus de découpe ou de
    légendes.
-   Le besoin produit a évolué : la cible n'est plus uniquement
    l'animation dans Synfig, mais un personnage jouable et un compagnon
    de bureau.
-   Godot est désormais la voie recommandée pour le runtime. Synfig
    reste optionnel pour des travaux d'animation dédiés.

## À ne pas faire

-   Ne pas utiliser les images de concept générées comme nouvelle source
    graphique.
-   Ne pas présenter les prototypes précédents comme terminés.
-   Ne pas écraser le pack d'origine.
-   Ne pas générer de nouvelles illustrations sans changement explicite
    de consigne.
