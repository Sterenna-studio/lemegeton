# Lemegeton --- dossier de passation du projet

> Document de référence pour reprendre le projet dans un dépôt Git.
> Langue de travail : français. Plateforme de développement confirmée :
> Windows. Niveau d'animation : débutant.

## Résumé exécutif

Lemegeton est un personnage robotique rétro inspiré d'un Minitel,
destiné à exister sous deux formes complémentaires : 1. un personnage
jouable dans un jeu 2D ; 2. un compagnon interactif sur le bureau
Windows.

La direction visuelle retenue est une marionnette 2D de type *jointed
paper doll / cut-out puppet* : pièces séparées, superposition, pivots et
mouvements articulés. La source graphique de référence est le pack
original fourni par l'utilisateur. **Ne pas générer de nouvelles
illustrations** pour cette étape : réutiliser, nettoyer, repositionner
et animer les assets existants uniquement.

La recommandation actuelle est Godot pour le runtime commun jeu +
compagnon de bureau. Synfig Studio reste une option d'atelier pour
préparer/tester des animations, mais il n'est pas nécessaire de
l'introduire dans le pipeline initial si cela complique le démarrage.

## Décisions confirmées

-   **OS cible de développement :** Windows.
-   **Niveau :** débutant en animation 2D.
-   **Cible produit :** jeu 2D + compagnon de bureau interactif.
-   **Style :** cut-out / paper puppet, articulations visuelles, pièces
    qui se chevauchent.
-   **Source d'art :** assets déjà présents dans le pack original.
-   **Interdit de production à ce stade :** pas de nouvelles
    illustrations générées.
-   **Mains :** une seule pose de main par bras dans une pose donnée ;
    les autres PNG sont des variantes interchangeables, jamais des mains
    permanentes dupliquées.
-   **Expressions :** une expression d'écran à la fois ; les PNG
    d'expressions sont des états alternatifs.
-   **Livrables précédents :** prototypes d'assemblage et d'animation
    sont des références, pas des rigs finaux.
-   **Priorité :** créer un prototype Godot minimal, testable et
    contrôlable, avant de développer le compagnon de bureau.

## Description visuelle et comportementale

Le personnage est un robot chibi inspiré d'un terminal Minitel rétro,
avec : - tête-écran CRT ; - expressions pixelisées cyan/magenta ; -
coque noire marbrée avec veines dorées/cuivrées ; - torse évoquant le
clavier d'un terminal ; - antenne ; - bras, mains et jambes courts ; -
accessoires/détails rétro présents dans les assets.

La direction paper-puppet doit venir de la façon d'assembler et d'animer
les images existantes, et non d'une nouvelle passe d'illustration :
pivots, superposition des raccords, animation par rotation/translation,
petites ombres éventuelles calculées par le moteur si cela n'exige pas
de nouvelles images sources.

## Architecture produit recommandée

### Phase 1 --- Prototype jouable Godot 2D

-   scène `Main` ;
-   personnage composé de pièces PNG ;
-   contrôles gauche/droite ;
-   saut et gravité ;
-   collisions sol/plateformes ;
-   état idle / marche / saut ;
-   changement d'expression déclenché par action ;
-   caméra simple et niveau de test minimal.

### Phase 2 --- Rig cut-out

-   pivots contrôlés pour cou, épaules, coudes, poignets, hanches,
    genoux et chevilles ;
-   hiérarchie des pièces ;
-   ordre de profondeur cohérent ;
-   correction des raccords et vérification des transparences ;
-   variantes de mains et d'expressions via remplacement d'état.

### Phase 3 --- Compagnon de bureau Windows

-   mode fenêtre sans bordure ;
-   option toujours au premier plan ;
-   fond transparent, après test sur la version de Godot et Windows
    retenues ;
-   déplacement du compagnon par glisser-déposer ;
-   clics / réactions simples ;
-   mode passif (idle), réactions à l'activité utilisateur ;
-   ne pas laisser les interactions du compagnon bloquer le jeu.

### Phase 4 --- Consolidation

-   sauvegarde des paramètres utiles ;
-   réglages d'accessibilité et de volume si nécessaire ;
-   tests de performance et de comportement de fenêtre ;
-   packaging Windows ;
-   README utilisateur et instructions de lancement.

## Structure de dépôt proposée

``` text
/
├── README.md
├── PROJECT_BRIEF.md
├── DECISIONS.md
├── ROADMAP.md
├── ASSET_INVENTORY.md
├── HISTORY_AND_ARTIFACTS.md
├── assets/
│   └── lemegeton/             # assets source validés, conservés sans altération
├── scenes/
│   ├── main/
│   ├── character/
│   └── desktop_companion/
├── scripts/
│   ├── character_controller.gd
│   ├── character_animation.gd
│   └── desktop_window.gd
├── animations/
├── tests/
└── docs/
```

Ne pas copier automatiquement tous les prototypes dans `assets/` de
production. Conserver les prototypes dans `reference_artifacts/` ou dans
un dossier d'archives jusqu'à validation.

## Risques / points à ne pas masquer

1.  Les PNG sont des découpes de travail et certains peuvent conserver
    des artefacts de la planche source. Un contrôle visuel est
    nécessaire.
2.  La tête et le torse disposent de certaines vues complètes : leurs
    sous-parties ne sont pas toutes séparées. L'écran indépendant doit
    être utilisé seulement si un asset correspondant existe réellement
    dans le pack.
3.  Les pivots présents dans les prototypes sont estimés et ne
    constituent pas une hiérarchie de rig finale.
4.  Le GIF de salut est un test de mouvement rudimentaire, pas une
    animation finale.
5.  Les capacités de fenêtre transparente, de clics traversants et de
    maintien au premier plan doivent être validées sur Windows avec la
    version de Godot ciblée.
6.  Le compagnon de bureau et le jeu 2D partagent les assets, mais leurs
    contrôleurs et leurs règles d'entrée doivent être séparés.
7.  Le format SVG et le fichier OpenRaster sont des références
    d'assemblage ; ils ne remplacent pas un projet Godot natif.

## Première tâche concrète recommandée

Créer un projet Godot 4.x minimal et importer uniquement les assets
utiles à la pose neutre : 1. tête/torse de base ; 2. bras supérieur et
inférieur de chaque côté ; 3. une main par côté ; 4. cuisse, jambe
inférieure et pied de chaque côté ; 5. antenne si elle ne fait pas déjà
partie de la tête complète.

Puis : - construire la scène du personnage avec des `Node2D`/`Sprite2D`
; - utiliser des nœuds parents comme pivots de rotation ; - tester une
rotation d'avant-bras ; - ajouter ensuite le contrôleur de déplacement
; - ne passer au compagnon de bureau qu'après validation du personnage
jouable.

La disponibilité exacte de chaque pièce doit être vérifiée dans
`manifest_assets.json`. Ne pas inventer de fichiers ou de ressources qui
n'existent pas.

## Règle de travail

Avant de modifier ou de remplacer un asset : - conserver l'original ; -
documenter la variante et la raison ; - ne jamais remplacer
silencieusement le pack source ; - éviter de dupliquer des pièces fixes
ou des mains ; - ne pas lancer de génération d'image pour résoudre un
problème d'assemblage.
