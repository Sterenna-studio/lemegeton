# Index des images et références visuelles

Ce dossier est une archive de référence visuelle, pas une nouvelle source de production.

## Illustrations conceptuelles
Les fichiers dans `illustrations_conceptuelles/` regroupent les illustrations et planches de concept conservées depuis le travail précédent. Elles servent à documenter l’évolution visuelle de Lemegeton et la direction cut-out/paper-puppet.

**Règle :** ne pas les substituer au pack source `source_assets/lemegeton_kit_rig_2d_original.zip`. Ne pas en extraire de nouvelles pièces de production sans validation explicite. Aucun nouvel artwork n’a été généré pour ce complément ; les fichiers existants ont été copiés.

## Aperçus techniques
`apercus_techniques/` contient des aperçus de kits, des prototypes SVG, une animation GIF de test et un aperçu Synfig. Ces éléments documentent les essais d’assemblage et les limites connues ; ils ne constituent pas un rig final.

## Source de vérité
Le pack `source_assets/lemegeton_kit_rig_2d_original.zip` reste la source graphique de référence. Il est conservé intact.
